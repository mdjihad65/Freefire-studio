// Netlify Serverless Function: contact.js
// Securely proxies user messages to Garena developer channels via Telegram Bot API and sends automatic client confirmation via Resend.

import fetch from 'node-fetch'; // Netlify functions support node-fetch natively, or we can use global fetch if available in Node 18+

// In-memory sliding-window tracker for IP-based rate limiting (stateless, per container instance)
const ipCache = new Map();
const RATE_LIMIT_MS = 10 * 60 * 1000; // 10 minutes sliding window
const MAX_REQUESTS = 3; // Maximum 3 messages allowed within the window

// Helper to sanitize input and escape HTML to prevent bot injections / formatting breaks
function sanitize(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export async function handler(event, context) {
  // 1. Enforce POST requests only
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Allow": "POST", "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Method Not Allowed. Only POST requests are permitted." })
    };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const { name, email, subject, message, metadata } = body;

    // 2. Extract Client Network and Geo IP Details from Netlify headers
    const headers = event.headers || {};
    const clientIP = headers['x-nf-client-connection-ip'] || headers['client-ip'] || headers['x-forwarded-for'] || "Unknown IP";
    const country = headers['x-country'] || "Unknown Country";

    // 3. Rate Limiting check
    const now = Date.now();
    let timestamps = ipCache.get(clientIP) || [];
    // Filter out timestamps older than the rate limit window
    timestamps = timestamps.filter(time => now - time < RATE_LIMIT_MS);
    
    if (timestamps.length >= MAX_REQUESTS) {
      return {
        statusCode: 429,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Too Many Requests. You have reached our message limit. Please try again in 10 minutes." })
      };
    }
    
    // Add current timestamp to rate-limit cache
    timestamps.push(now);
    ipCache.set(clientIP, timestamps);

    // 4. Server-side inputs validation and sanitization
    if (!name || !subject || !message) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Bad Request. Name, Subject, and Message are required fields." })
      };
    }

    if (message.length < 10) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Bad Request. Message must be at least 10 characters long." })
      };
    }

    const sanitizedName = sanitize(name.trim());
    const sanitizedEmail = email ? email.trim() : "";
    const sanitizedSubject = sanitize(subject.trim());
    const sanitizedMessage = sanitize(message.trim());

    if (sanitizedEmail) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(sanitizedEmail)) {
        return {
          statusCode: 400,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "Bad Request. Please provide a valid email format." })
        };
      }
    }

    // 5. Build and send the Garena Telegram Notification
    const botToken = process.env.BOT_TOKEN;
    const chatId = process.env.CHAT_ID;

    if (!botToken || !chatId) {
      console.error("Configuration Error: BOT_TOKEN or CHAT_ID is missing from environmental variables.");
      return {
        statusCode: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Internal Server Configuration Error. Please contact support." })
      };
    }

    // Build responsive HTML string for Telegram message
    const telegramMessage = `
<b>✉️ NEW SECURE MESSAGE RECEIVED - FF STUDIO</b>

<b>👤 SENDER PROFILE:</b>
• <b>Name:</b> ${sanitizedName}
• <b>Email:</b> ${sanitizedEmail ? `<code>${sanitizedEmail}</code>` : '<i>Not provided</i>'}

<b>📝 INQUIRY OVERVIEW:</b>
• <b>Subject:</b> ${sanitizedSubject}
• <b>Message:</b>
<pre>${sanitizedMessage}</pre>

<b>🌐 VISITOR ENVIRONMENTAL ANALYTICS:</b>
• <b>Client Connection IP:</b> <code>${clientIP}</code>
• <b>Netlify GeoIP Country:</b> <b>${country}</b>
• <b>Local Client Time:</b> <code>${metadata?.localTime || 'N/A'}</code>
• <b>Timezone Offset:</b> <code>${metadata?.timezone || 'N/A'}</code>
• <b>Device Category:</b> <i>${metadata?.deviceType || 'N/A'}</i>
• <b>Operating System:</b> <i>${metadata?.os || 'N/A'}</i>
• <b>Client Web Browser:</b> <i>${metadata?.browser || 'N/A'}</i>
• <b>Display Resolution:</b> <code>${metadata?.resolution || 'N/A'}</code>
• <b>Language ISO Code:</b> <code>${metadata?.language || 'N/A'}</code>
• <b>Submission Page URL:</b> <a href="${metadata?.pageUrl || '#'}">FF Contact Page</a>
• <b>HTTP Referrer Value:</b> <i>${metadata?.referrer || 'N/A'}</i>
`.trim();

    // Fire HTTP call to Telegram
    const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const tgResponse = await fetch(telegramUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: telegramMessage,
        parse_mode: 'HTML',
        disable_web_page_preview: true
      })
    });

    if (!tgResponse.ok) {
      const errText = await tgResponse.text();
      console.error("Telegram API Error Response:", errText);
      throw new Error("Failed to dispatch Garena Telegram Alert notification.");
    }

    // 6. Optional: Send auto-confirmation receipt using Resend API
    const resendApiKey = process.env.RESEND_API_KEY;
    if (sanitizedEmail && resendApiKey) {
      const resendUrl = 'https://api.resend.com/emails';
      
      const emailHtmlBody = `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 580px; margin: 0 auto; padding: 24px; background-color: #ffffff; border: 1px solid #f3f3f5; border-radius: 16px;">
          <div style="display: flex; align-items: center; margin-bottom: 24px;">
            <div style="width: 32px; height: 32px; background-color: #e11d48; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 16px; margin-right: 10px; text-align: center; line-height: 32px;">FF</div>
            <span style="font-size: 18px; font-weight: bold; color: #09090b;">FF Studio <span style="color: #e11d48;">Support</span></span>
          </div>
          
          <h2 style="font-size: 20px; font-weight: 800; color: #09090b; margin-top: 0; margin-bottom: 8px;">Message Dispatched Successfully!</h2>
          <p style="font-size: 14px; color: #52525b; line-height: 1.6; margin-top: 0; margin-bottom: 24px;">
            Hi <strong>${sanitizedName}</strong>,<br><br>
            We received your inquiry regarding <strong>"${sanitizedSubject}"</strong>. Our esports dev team is on it! Below is a copy of your submitted message for your records:
          </p>
          
          <div style="background-color: #fafafa; border: 1px solid #f4f4f5; border-radius: 12px; padding: 18px; margin-bottom: 24px;">
            <p style="font-size: 13px; font-weight: bold; color: #71717a; margin-top: 0; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px;">Your Message Copy</p>
            <p style="font-size: 14px; color: #18181b; line-height: 1.6; margin: 0; white-space: pre-wrap;">${sanitizedMessage}</p>
          </div>
          
          <p style="font-size: 12px; color: #a1a1aa; line-height: 1.6; margin-top: 24px; margin-bottom: 0; border-top: 1px solid #f4f4f5; padding-top: 16px; text-align: center;">
            FF Studio &copy; 2026. This is an automated secure receipt. Do not reply to this email directly.
          </p>
        </div>
      `.trim();

      const emailPayload = {
        from: 'FF Studio <onboarding@resend.dev>',
        to: [sanitizedEmail],
        subject: `We received your message: ${sanitizedSubject} - FF Studio`,
        html: emailHtmlBody
      };

      try {
        const resendResponse = await fetch(resendUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${resendApiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(emailPayload)
        });

        if (!resendResponse.ok) {
          const resendErr = await resendResponse.text();
          console.error("Resend API Failure:", resendErr);
        }
      } catch (emailErr) {
        // Log Resend failure but do not crash the Telegram success response
        console.error("Non-blocking failure: Unable to send Resend email receipt:", emailErr);
      }
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ success: true, message: "Secure transmission completed." })
    };

  } catch (error) {
    console.error("Serverless Function Runtime Error:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: error.message || "An unexpected error occurred inside the contact function gateway." })
    };
  }
}
